Getting started
===============

.. toctree::
   :maxdepth: 1

   installation
   a_first_example
   examples

..   further_examples
