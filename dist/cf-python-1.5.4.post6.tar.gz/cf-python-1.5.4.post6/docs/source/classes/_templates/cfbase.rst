{{ fullname }}
{{ underline }}

.. auto{{ objtype }}:: {{ fullname }}
