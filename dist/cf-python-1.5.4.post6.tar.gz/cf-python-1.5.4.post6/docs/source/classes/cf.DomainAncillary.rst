.. currentmodule:: cf
.. default-role:: obj

cf.DomainAncillary
==================

.. autoclass:: DomainAncillary
   :no-members:
   :no-inherited-members:

DimensionCoordinate CF methods
------------------------------

.. autosummary::
   :nosignatures:
   :toctree: ../generated/
   :template: method.rst

   ~DomainAncillary.all
   ~DomainAncillary.allclose
   ~DomainAncillary.any
   ~DomainAncillary.append
   ~DomainAncillary.asdatetime
   ~DomainAncillary.asreftime
   ~DomainAncillary.attributes
   ~DomainAncillary.ceil
   ~DomainAncillary.chunk
   ~DomainAncillary.clip
   ~DomainAncillary.close
   ~DomainAncillary.concatenate
   ~DomainAncillary.contiguous
   ~DomainAncillary.convert_reference_time
   ~DomainAncillary.copy
   ~DomainAncillary.cos
   ~DomainAncillary.count
   ~DomainAncillary.cyclic
   ~DomainAncillary.datum
   ~DomainAncillary.delprop
   ~DomainAncillary.direction
   ~DomainAncillary.dump
   ~DomainAncillary.equals
   ~DomainAncillary.equivalent
   ~DomainAncillary.exp
   ~DomainAncillary.expand_dims
   ~DomainAncillary.extend
   ~DomainAncillary.files
   ~DomainAncillary.fill_value
   ~DomainAncillary.flip
   ~DomainAncillary.floor
   ~DomainAncillary.getprop
   ~DomainAncillary.hasprop
   ~DomainAncillary.HDF_chunks
   ~DomainAncillary.identity
   ~DomainAncillary.index
   ~DomainAncillary.insert
   ~DomainAncillary.insert_bounds
   ~DomainAncillary.insert_data
   ~DomainAncillary.inspect
   ~DomainAncillary.log
   ~DomainAncillary.mask_invalid
   ~DomainAncillary.match
   ~DomainAncillary.max
   ~DomainAncillary.mean
   ~DomainAncillary.mid_range
   ~DomainAncillary.min
   ~DomainAncillary.name
   ~DomainAncillary.override_calendar
   ~DomainAncillary.override_units
   ~DomainAncillary.pop
   ~DomainAncillary.properties
   ~DomainAncillary.range
   ~DomainAncillary.remove
   ~DomainAncillary.remove_data
   ~DomainAncillary.rint
   ~DomainAncillary.roll
   ~DomainAncillary.round
   ~DomainAncillary.sample_size
   ~DomainAncillary.sd
   ~DomainAncillary.select
   ~DomainAncillary.set_equals
   ~DomainAncillary.setprop
   ~DomainAncillary.sin
   ~DomainAncillary.squeeze
   ~DomainAncillary.sum
   ~DomainAncillary.tan
   ~DomainAncillary.transpose
   ~DomainAncillary.trunc
   ~DomainAncillary.unique
   ~DomainAncillary.var
   ~DomainAncillary.where
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~DomainAncillary.Data
      ~DomainAncillary.T
      ~DomainAncillary.Units
      ~DomainAncillary.X
      ~DomainAncillary.Y
      ~DomainAncillary.Z
      ~DomainAncillary.add_offset
      ~DomainAncillary.array
      ~DomainAncillary.binary_mask
      ~DomainAncillary.bounds
      ~DomainAncillary.calendar
      ~DomainAncillary.cellsize
      ~DomainAncillary.comment
      ~DomainAncillary.data
      ~DomainAncillary.day
      ~DomainAncillary.dtarray
      ~DomainAncillary.dtvarray
      ~DomainAncillary.dtype
      ~DomainAncillary.hardmask
      ~DomainAncillary.hasbounds
      ~DomainAncillary.hasdata
      ~DomainAncillary.history
      ~DomainAncillary.hour
      ~DomainAncillary.isauxiliary
      ~DomainAncillary.isdimension
      ~DomainAncillary.isdomainancillary
      ~DomainAncillary.isfieldancillary
      ~DomainAncillary.ismeasure
      ~DomainAncillary.isperiodic
      ~DomainAncillary.isscalar
      ~DomainAncillary.leap_month
      ~DomainAncillary.leap_year
      ~DomainAncillary.long_name
      ~DomainAncillary.lower_bounds
      ~DomainAncillary.mask
      ~DomainAncillary.minute
      ~DomainAncillary.missing_value
      ~DomainAncillary.month
      ~DomainAncillary.month_lengths
      ~DomainAncillary.ndim
      ~DomainAncillary.reference_datetime
      ~DomainAncillary.scale_factor
      ~DomainAncillary.second
      ~DomainAncillary.shape
      ~DomainAncillary.size
      ~DomainAncillary.standard_name
      ~DomainAncillary.subspace
      ~DomainAncillary.units
      ~DomainAncillary.unsafe_array
      ~DomainAncillary.upper_bounds
      ~DomainAncillary.valid_max
      ~DomainAncillary.valid_min
      ~DomainAncillary.valid_range
      ~DomainAncillary.varray
      ~DomainAncillary.year
   
   
