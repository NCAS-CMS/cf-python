{{ fullname }}
{{ underline }}

.. currentmodule:: cf
.. default-role:: obj

.. automethod:: {{ fullname }}
