{{ fullname }}
{{ underline }}

.. currentmodule:: cf
.. default-role:: obj

.. autoattribute:: {{ fullname }}
