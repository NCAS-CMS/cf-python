{{ fullname }}
{{ underline }}

.. currentmodule:: cf
.. default-role:: obj

.. autofunction:: {{ fullname }}
